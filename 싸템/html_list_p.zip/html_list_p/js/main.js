document.addEventListener('DOMContentLoaded', () => {
	const mainSwiper = new Swiper('.main_visual .swiper', {
		slidesPerView: 1,
		spaceBetween: 100,
		loop: true,
		loopAdditionalSlides: 2,
	});
});